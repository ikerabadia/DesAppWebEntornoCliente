//3- Haz un programa que escriba en una lista no ordenada todos los múltiplos de 23 inferiores a 1000 y por último nos dé la suma de todos ellos.
//Ayuda: document.write("<li>"+numero+"</li>");

for (let i = 23; i < 1000; i=i+23) {

    document.write("<li>"+i+"</li>");
    
}


