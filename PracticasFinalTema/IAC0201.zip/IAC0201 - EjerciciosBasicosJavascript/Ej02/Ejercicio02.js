//2-Realiza un programa que funcione de la siguiente forma:
//a) El programa nos pregunta nuestro nombre mediante promt.
//b) El programa nos pregunta nuestra edad mediante promt.
//c) El programa muestra un alert saludándonos por nuestro nombre y a continuación los días que hemos vivido hasta el momento (deberías multiplicar la edad por 365)

var nombre = prompt("Escribe tu nombre");
var edad = prompt("Edad");

alert("Hola " + nombre + ", has vivido " + edad*365 + " dias.");


