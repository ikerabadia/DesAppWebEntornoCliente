/*2. Escribir una función de JavaScript para añadir filas a una tabla.*/
function añadirFila(){
    var tabla = document.getElementById("tabla");
    tabla.innerHTML+="<tr><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>";
}


