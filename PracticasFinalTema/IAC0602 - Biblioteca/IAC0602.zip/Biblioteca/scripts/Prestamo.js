class Prestamo{
    constructor(copia, fInicio, fFin){
        this.copia = copia;
        this.fInicio = fInicio;
        this.fFin = fFin;
    }

    getCopia(){
        return this.copia;
    }
    getFFin(){
        return this.fFin;
    }
}