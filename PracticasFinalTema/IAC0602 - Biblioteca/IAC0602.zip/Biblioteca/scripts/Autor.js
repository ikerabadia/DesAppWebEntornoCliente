class Autor{
    constructor(nombre, nacionalidad, fechaNacimiento){
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.fechaNacimiento = fechaNacimiento;
    }
    getNombre(){
        return this.nombre;
    }
}