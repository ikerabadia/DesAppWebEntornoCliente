class Multa{
    constructor (fInicio, fFin){
        this.fInicio = fInicio;
        this.fFin = fFin;
    }

    getFInicio(){
        return this.fInicio;
    }
    getFFin(){
        return this.fFin;
    }
}