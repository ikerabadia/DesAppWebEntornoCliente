Coche = function(matricula, marca, modelo, potenciaCV) {
    this.matricula = matricula;
    this.marca = marca;
    this.modelo = modelo;
    this.potenciaCV = potenciaCV;
}