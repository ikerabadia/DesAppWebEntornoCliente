Cliente = function(dni) {
    this.dni = dni;
    this.coches = [];
}

function comprarCoche(coche) {
    this.coches.push(coche);
}

